Plugin Name: Price Converter
Plugin URI:
Description: This plugin will convert product price for user
Author: Krishnasinh 
Author URI:
Version:1.0

<html>
<head><title>Product Price Converter</title></head>
<body align="center">
<h3>Product Price Converter</h1>
<form action="Home" method="get">
Enter Currency : <input type="text" name="currency" />
Select Currency :
<select name="dropdown">
<option value="usd">Us Dollar</option>
<option value="cad">Canadian Dollar</option>
<option value="gbp">British Pound</option>
</select>
<input type="submit" name="sbmt" value="Convert" />
</form>
</body>
</html>

<?php

	if(isset($_GET['sbmt']))
    {
        $cc_input = $_GET['currency'];
        $cc_dropdown = $_GET['dropdown'];

       if($cc_dropdown == 'usd')
        {
            // Current source URL: http://www.xe.com/currencyconverter/convert/?Amount=1&From=INR&To=USD
			$output = $cc_input * 0.0153719;
            echo "<h1>" . number_format($output,2) . " Dollar" . "</h1>";
        }
        else if($cc_dropdown == 'cad')
        {
            // Current source URL: http://www.xe.com/currencyconverter/convert/?Amount=1&From=INR&To=CAD
			$output = $cc_input * 0.0196708;
            echo "<h1>" . number_format($output,2) . " Canadian Dollar" . "</h1>";
        }
        else if($cc_dropdown == 'gbp')
        {
            //Current source URL: http://www.xe.com/currencyconverter/convert/?Amount=1&From=INR&To=GBP
			$output = $cc_input * 0.0116152;
           echo "<h1>" . number_format($output,2) . " British Pound" . "</h1>";
        }
    }
?>﻿